Каноническое состояние системы vsepro100.info
Обновлено: 2026-01-21
1. Статус системы (фактический)

Система находится в продакшене.
Пользователи активны.

Ранее выявленный инцидент безопасности
(JS/HTML malware, fake Cloudflare overlay) полностью закрыт.
Повторного заражения не выявлено.

Hardening выполнен:

на уровне WordPress,

на уровне сервера.

Внешний Cloudflare / WAF осознанно не используется
(архитектурное решение).

Система работает стабильно.

2. Архитектурный статус (высокий уровень)

Система переведена на модульную Core-архитектуру.

Завершены и закрыты домены:

Ingest — полностью

Lead (Phase 1) — foundation, routing, observability

Все новые домены развиваются ТОЛЬКО через Core-модули.

Legacy-код:

сохранён исключительно как адаптеры,

не содержит бизнес-логики,

не является точкой расширения.

3. Активные модули (по факту, WordPress → Активные плагины)
Core

Core Engine

Тип: Core

Назначение:

канонический ingest pipeline

оркестрация ingest-подтипов

декларативный реестр ingest

Контракт:

core_ingest_event (v1, зафиксирован)

Статус: активен, стабилен

Core Lead Engine

Тип: Core

Назначение:

каноническая точка входа lead-событий

якорь домена Lead

Контракт:

core_lead_created

core_lead_updated

core_lead_deleted

core_lead_merged

Статус: активен (foundation + routing одного entry)

Integration / Adapter

AutoWebinar Delivery

Тип: Integration

Назначение:

генерация событий автовебинара

Ограничения:

hooks-only

без UI

без бизнес-логики

Core Legacy Event Bridge

Тип: Integration (Adapter)

Назначение:

legacy-точки входа

делегирование событий в Core

Ограничения:

adapter-only

логика запрещена

Service / Observer

Service Telegram Notifier

Тип: Service

Назначение:

уведомления в Telegram

Слушает:

core_ingest_event

Конфигурация:

TELEGRAM_BOT_TOKEN (wp-config.php)

TELEGRAM_CHAT_ID (wp-config.php)

Core Ingest Observer

Тип: Service (Observer)

Назначение:

наблюдение ingest-потока

сбор метрик

Слушает:

core_ingest_event

Метрики:

total ingest events

per subtype counts

last ingest timestamp

Admin UI:

Tools → Ingest Metrics (read-only)

Core Lead Observer

Тип: Service (Observer)

Назначение:

наблюдение lead-событий

сбор метрик

Слушает:

core_lead_created

Метрики:

total leads created

last lead creation timestamp

Admin UI:

Tools → Lead Metrics (read-only)

4. Канонические события (hooks)
Ingest

core_ingest_event

Контракт: v1 (заморожен)

Единственная точка fan-out для ingest

Lead

core_lead_created

core_lead_updated

core_lead_deleted

core_lead_merged

5. Подтверждённые архитектурные факты

Core — единственное место логики

Services:

реагируют только на Core events

не вызывают друг друга

Integration:

только формируют payload

не содержат бизнес-решений

Legacy:

adapter-only

развитие запрещено

Любые новые домены:

стартуют с пустого Core-фундамента,

развиваются по проверенному паттерну:
foundation → routing → observer → metrics → cleanup.

6. Текущее состояние roadmap

Закрыто:

Ingest Core MVP

Ingest Observability + Metrics + Admin UI

Legacy Ingest Cleanup (phase 1–2)

Core Lead Engine (foundation)

Lead routing (1 entry)

Lead Observability + Metrics + Admin UI

Активный этап:

Core Lead Engine — Phase 2

масштабирование lead-entry

дальнейшая миграция legacy

подготовка канонической lead-сущности

7. Канонический статус

SYSTEM_STATE.md
является единственным источником правды
о фактическом состоянии платформы.

История чатов, устные договорённости и промежуточные решения
не считаются актуальными, если не отражены здесь.