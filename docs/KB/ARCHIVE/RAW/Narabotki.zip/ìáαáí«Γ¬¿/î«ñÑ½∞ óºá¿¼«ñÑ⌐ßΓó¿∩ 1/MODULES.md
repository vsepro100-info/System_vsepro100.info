📄 MODULES.md
(Эталонный список модулей)

## Границы модулей (обязательно)
- Core — единственный, кто создаёт/изменяет lead_entry и lead_meta
- Integration — ТОЛЬКО формирует payload и вызывает hook
- Service — ТОЛЬКО реагирует на события Core
- UI — ТОЛЬКО читает данные, не влияет на бизнес-логику
Нарушение границ = архитектурная ошибка.


## Core
- core-lead-engine
  Тип: Core
  Назначение: принять lead_payload, валидировать, создать lead_entry, сформировать lead_meta, испустить канонические события


## Integration
- bot-runtime-telegram
  Тип: Integration
  Назначение: принять update от Telegram, сформировать lead_payload, передать в Core через hook lead_router_handle
- traffic-entry-forms
  Тип: Integration
  Назначение: принять заявку с сайта, сформировать lead_payload, передать в Core через hook lead_router_handle

## Service
- referral-engine
  Тип: Service
  Назначение: обработка ref/цепочек через события core

- partner-engine
  Тип: Service
  Назначение: партнёры/статусы/привязки через события core

- partner-stats-payments
  Тип: Service
  Назначение: статистика/начисления через события core

## UI / Admin
- lead-admin-tools
  Тип: UI
  Назначение: просмотр/фильтры/экспорт заявок (без вмешательства в core-логику)

## Debug (только dev)
- system-ingest-debugger
  Тип: Debug
  Назначение: диагностический вывод входящих payload и событий (в проде выключен)
